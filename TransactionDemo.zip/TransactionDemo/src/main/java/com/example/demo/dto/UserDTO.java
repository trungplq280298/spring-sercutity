package com.example.demo.dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class UserDTO implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = -6103458830266023669L;

    @NotNull
    private Integer idUser;

    @NotNull
    private String userName;

    @NotNull
    private String passWord;

    public UserDTO() {
    }

    public Integer getIdUser() {
        return idUser;
    }

    public void setIdUser(Integer idUser) {
        this.idUser = idUser;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String toString() {
        return "id :" + this.idUser + " " + "username :" + this.userName + " " + "password :" + this.passWord;
    }
}
