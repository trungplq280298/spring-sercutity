package com.example.demo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Exception.RollbackException;
import com.example.demo.dto.UserDetailDTO;
import com.example.demo.mapper.UserMapper;
import com.example.demo.model.User;
import com.example.demo.model.UserDetail;
import com.example.demo.repository.UserDetailRepository;
import com.example.demo.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserDetailRepository userDetailRepository;

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> findAllUser() {
        // TODO Auto-generated method stub
        return (List<User>) userRepository.findAll();
    }

    @Transactional(rollbackOn = RollbackException.class)
    @Override
    public void save(UserDetailDTO userDetailDTO) {
        try {
            userRepository.save(userMapper.toUser(userDetailDTO));
            userDetailRepository.save(userMapper.toUserDetail(userDetailDTO));
        } catch (Exception e) {
            
        }
    }
}
