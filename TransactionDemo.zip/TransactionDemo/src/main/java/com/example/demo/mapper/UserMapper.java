package com.example.demo.mapper;

import org.springframework.stereotype.Component;

import com.example.demo.dto.UserDetailDTO;
import com.example.demo.model.User;
import com.example.demo.model.UserDetail;

@Component
public class UserMapper {

    public User toUser(UserDetailDTO dto) {

        User user = new User();
        user.setUsername(dto.getUsername());
        user.setPassword(dto.getPassword());
        return user;
    }
    
    public UserDetail toUserDetail(UserDetailDTO dto) {

        UserDetail userDetail = new UserDetail();
        userDetail.setNameUser(dto.getName());
        userDetail.setAddressUser(dto.getAddress());
        userDetail.setPhoneUser(dto.getPhone());
        return userDetail;
    }
}
