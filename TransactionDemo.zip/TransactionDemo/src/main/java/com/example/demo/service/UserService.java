package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.UserDetailDTO;
import com.example.demo.model.User;

public interface UserService {
    // return List<User> from User
    List<User> findAllUser();

    // insert new user
    void save(UserDetailDTO userDetailDTO) throws Exception;

}
