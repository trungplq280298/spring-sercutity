package com.example.demo.Exception;

public class RollbackException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public RollbackException(String errorMessage) {
        super(errorMessage + "RollBackData");
    }
}
