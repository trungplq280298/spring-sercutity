/**
 * View Models used by Spring MVC REST controllers.
 */
package jp.datnt.demo.web.rest.vm;
