/**
 * Spring Data JPA repositories.
 */
package jp.datnt.demo.repository;
