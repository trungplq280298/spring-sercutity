/**
 * JPA domain objects.
 */
package jp.datnt.demo.domain;
