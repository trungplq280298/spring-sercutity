/**
 * Spring MVC REST controllers.
 */
package jp.datnt.demo.web.rest;
