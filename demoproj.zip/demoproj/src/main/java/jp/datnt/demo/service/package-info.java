/**
 * Service layer beans.
 */
package jp.datnt.demo.service;
